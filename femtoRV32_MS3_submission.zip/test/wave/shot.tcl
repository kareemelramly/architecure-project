set fh [open "signals.txt" r]
set sigs {}
while {[gets $fh line] >= 0} { if {$line ne ""} { lappend sigs $line } }
close $fh
foreach s $sigs { gtkwave::addSignalsFromList [list $s] }
gtkwave::setZoomFactor -2
