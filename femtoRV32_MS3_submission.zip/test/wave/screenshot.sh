#!/bin/sh
# Takes the GTKWave screenshots used in the report (needs gtkwave, xvfb, imagemagick).
# Run after make_waves.sh, from test/wave/:  sh screenshot.sh
cat > /tmp/gtkwaverc <<'RC'
initial_window_x 1780
initial_window_y 980
enable_vert_grid 1
RC
(Xvfb :99 -screen 0 1800x1000x24 >/dev/null 2>&1 &); sleep 2
shot() {  # name start_ps end_ps tag
  { cat shot.tcl; echo "gtkwave::setZoomRangeTimes $2 $3"; } > /tmp/$1_$4.tcl
  DISPLAY=:99 gtkwave -r /tmp/gtkwaverc -f $1.vcd -S /tmp/$1_$4.tcl >/dev/null 2>&1 &
  GP=$!; sleep 7
  DISPLAY=:99 import -window root /tmp/$1_$4.png
  kill $GP 2>/dev/null; sleep 1
  convert /tmp/$1_$4.png -crop 1500x585+280+95 +repage screenshots/wave_$1_$4.png
}
shot demo 0 35000 full
shot demo 9000 20000 hazard
shot quick 0 120000 full
shot quick 46000 66000 memory
shot quick 84000 104000 muldiv
shot hazards 0 160000 full
shot full_test 0 485000 full
