#!/bin/sh
# Builds the VCD files shown in the report. Run from test/wave/:  sh make_waves.sh
V=../../Verilog; P=../programs
RTL="$V/ALU.v $V/alu_unit.v $V/BranchUnit.v $V/control_unit.v $V/DFlipFlop.v
     $V/ForwardingUnit.v $V/ImmGen.v $V/mux2x1.v $V/N_bit_register.v
     $V/Nbit_decoder.v $V/PhaseController.v $V/pipeline.v $V/PipelineReg.v
     $V/RegFile.v $V/UnifiedMem.v $V/pipeline_tb.v wave_dump.v"
for p in demo quick hazards all_instr; do
  iverilog -g2012 -I$V -s pipeline_tb -s wave_dump -DVCDFILE=\"$p.vcd\" \
    -Ppipeline_tb.VERBOSE=0 -Ppipeline_tb.COVERAGE=0 \
    -Ppipeline_tb.PROG=\"$P/$p.hex\" $RTL -o /tmp/w_$p.out && vvp -n /tmp/w_$p.out | grep -E "TEST|instructions checked"
done
iverilog -g2012 -I$V -s pipeline_tb -s wave_dump -DVCDFILE=\"full_test.vcd\" $RTL -o /tmp/w_full.out && vvp -n /tmp/w_full.out | grep -E "TEST|instructions checked"
