// wave_dump.v: dumps a VCD for GTKWave. Separate top module, so none of the
// design or testbench files is modified. Compile it next to pipeline_tb:
//   iverilog -g2012 -I../../Verilog -s pipeline_tb -s wave_dump -DVCDFILE=\"demo.vcd\" ...
`timescale 1ns / 1ps
module wave_dump;
    initial begin
        $dumpfile(`VCDFILE);
        $dumpvars(0, pipeline_tb.dut);
        $dumpvars(0, pipeline_tb.rst);
    end
endmodule
